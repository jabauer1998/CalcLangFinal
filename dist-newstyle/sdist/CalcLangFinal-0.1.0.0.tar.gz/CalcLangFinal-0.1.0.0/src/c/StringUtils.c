#include "StringUtils.h"
#include <string.h>

//Function to append a Character to the givin string
void appendStrChr(char a, int size, char* str){
  int actualLength = strlen(str);
  if(actualLength < (size - 1)){
    // Append the character
    str[actualLength] = a;
    // Add the new null terminator
    str[actualLength + 1] = '\0';
  }
}
