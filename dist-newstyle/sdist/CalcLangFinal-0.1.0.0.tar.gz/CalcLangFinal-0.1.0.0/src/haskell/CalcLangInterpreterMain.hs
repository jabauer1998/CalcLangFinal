module Main where

import CalcLangInterpreter

main :: IO ()
main = runCalcLang
